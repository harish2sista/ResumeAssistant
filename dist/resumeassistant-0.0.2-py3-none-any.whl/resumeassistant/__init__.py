'''
Copyright (C), 2024, Harish Sista. 

resumeassistant project
'''

__name__ = ''
__author__ = 'Harish Sista'
__all__ = ['data', 'utils', 'operator']


from resumeassistant.operator import worker
from resumeassistant.data import candidate_record